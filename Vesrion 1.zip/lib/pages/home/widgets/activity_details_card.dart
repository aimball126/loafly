import 'package:flutter/material.dart';
import 'package:flutter_dashboard/widgets/custom_card.dart';

class BreadModel {
  final String icon;
  final String value;
  final String quantity;
  final String value2;
  final String delivery;
  final String data;
  final String amount;
  final double price;
  const BreadModel(
      {required this.icon, required this.value, required this.quantity, required this.value2, required this.delivery, required this.data, required this.amount, required this.price});
}


class ActivityDetailsCard extends StatelessWidget {
  const ActivityDetailsCard({Key? key}) : super(key: key);


  final List<BreadModel> breadDetails = const [
    BreadModel(icon: 'assets/images/Bread.png', value: "   خبز", quantity: "الكمية", value2: "5", delivery: "الزمن", data: "وقت 15-20 دقييقة", amount: "المبلغ", price: 20.99),
    BreadModel(icon: 'assets/images/Brioche.png', value: "بريوش", quantity: "الكمية", value2: "5" ,delivery: "الزمن", data: "وقت 15-20 دقييقة", amount: "المبلغ", price: 25.99),
    BreadModel(icon: 'assets/images/Candies.png', value: "حلويات", quantity: "الكمية", value2: "2", delivery: "الزمن", data: "وقت 15-20 دقييقة", amount: "المبلغ", price: 25.99),
    BreadModel(icon: 'assets/images/Crackers.png', value: "المقرمشات", quantity: "الكمية", value2: "5", delivery: "الزمن", data: "وقت 15-20 دقييقة", amount: "المبلغ", price: 20.99),
  ];


  @override

  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: breadDetails.length,
      shrinkWrap: true,
      physics: const ScrollPhysics(),
      itemBuilder: (context, i) {
        return Column(
          children: [
            if (i == 0)
              const Align(
                alignment: Alignment.centerRight,
                child: Column(
                        children: [
                          Text(
                            "عرض المنتجات",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 12.0),
                        ],
                      ),
                    ),
            CustomCard(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 15, bottom: 4),
                        child: Image.asset(
                          breadDetails[i].icon,
                          width: 50,
                          height: 50,
                        ), // Adjust the size as needed
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 15, bottom: 4),
                        child: Text(
                          breadDetails[i].value,
                          style: const TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 15, bottom: 12),
                          child: Text(
                            breadDetails[i].quantity,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ),
                        Text(
                          breadDetails[i].value2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.grey,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 15, bottom: 12),
                          child: Text(
                            breadDetails[i].delivery,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ),
                        Text(
                          breadDetails[i].data,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.grey,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 15, bottom: 12),
                          child: 
                          Text(
                              breadDetails[i].amount,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          Text(
                            '\$${breadDetails[i].price.toStringAsFixed(2)}',
                            style: const TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0), // Add spacing between the cards
          ],
        );
      },
    );
  }
}